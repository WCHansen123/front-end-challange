<?php
require 'models/todo_list.php';
require 'models/list_item.php';
require 'controllers/todoListController.php';

?>
    <!DOCTYPE html>
    <html>
    <head>
        <!--Import Google Icon Font-->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!--Import materialize.css-->
        <link type="text/css" rel="stylesheet" href="resources/css/materialize.min.css"  media="screen,projection"/>

        <!--Let browser know website is optimized for mobile-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

    <body>
    <?php
    foreach(todo_list::fetchAll() as $array)
    {
    ?>

    <ul class="collection with-header">
        <li class="collection-header"><h4><?php echo $array['name'] ?></h4></li>
        <li class="collection-item"><?php echo $array['name'] ?></li>

        <?php
        }
        ?>
    </ul>
    <!--JavaScript at end of body for optimized loading-->
    <script type="text/javascript" src="resources/js/materialize.min.js"></script>
    </body>
    </html>
