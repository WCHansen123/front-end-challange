<?php
require "resources/database.php";

class todo_list
{
    private $name, $list_item;

    function __construct($name, $list_item)
    {
        $this->name = $name;
        $this->list_item = [$list_item];
    }

    public static function fetchAll () {
        $conn = MakeSQLConnection();

        $query = "SELECT * FROM todo_list";

        $stmt = $conn->prepare($query);
        $stmt->execute();
        $stmt->setFetchMode(PDO::FETCH_ASSOC);

        $planning= $stmt-> fetchAll();
        $conn = null;
        return $planning;
    }

    function getName() {
        return $this->name;
    }

    function getList_item() {
        return $this->list_item;
    }
}